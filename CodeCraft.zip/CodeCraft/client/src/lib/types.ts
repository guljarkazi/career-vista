// Common types used across components
export interface TrackTypeColors {
  Medical: {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  Engineering: {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  Reading: {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  Skills: {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  IAS: {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  "Future Tech": {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
  "Life Skills": {
    bg: string;
    text: string;
    progressBar: string;
    button: string;
    hoverButton: string;
  };
}

export const trackTypeColors: TrackTypeColors = {
  Medical: {
    bg: "bg-blue-100",
    text: "text-blue-700",
    progressBar: "bg-primary-600",
    button: "bg-primary-600",
    hoverButton: "hover:bg-primary-700",
  },
  Engineering: {
    bg: "bg-purple-100",
    text: "text-purple-700",
    progressBar: "bg-purple-600",
    button: "bg-purple-600",
    hoverButton: "hover:bg-purple-700",
  },
  Reading: {
    bg: "bg-indigo-100",
    text: "text-indigo-700",
    progressBar: "bg-secondary-500",
    button: "bg-secondary-500",
    hoverButton: "hover:bg-secondary-600",
  },
  Skills: {
    bg: "bg-green-100",
    text: "text-green-700",
    progressBar: "bg-green-500",
    button: "bg-green-600",
    hoverButton: "hover:bg-green-700",
  },
  IAS: {
    bg: "bg-amber-100",
    text: "text-amber-700",
    progressBar: "bg-amber-500",
    button: "bg-amber-500",
    hoverButton: "hover:bg-amber-600",
  },
  "Future Tech": {
    bg: "bg-cyan-100",
    text: "text-cyan-700",
    progressBar: "bg-cyan-500",
    button: "bg-cyan-600",
    hoverButton: "hover:bg-cyan-700",
  },
  "Life Skills": {
    bg: "bg-emerald-100",
    text: "text-emerald-700",
    progressBar: "bg-emerald-500",
    button: "bg-emerald-600",
    hoverButton: "hover:bg-emerald-700",
  },
};
