import { format } from "date-fns";
import { WeeklyPlan as WeeklyPlanType } from "@shared/schema";

interface WeeklyPlanProps {
  plans: WeeklyPlanType[];
}

export default function WeeklyPlanView({ plans }: WeeklyPlanProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
      <h3 className="text-lg font-semibold mb-4">Your Weekly Plan</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan) => (
          <div 
            key={plan.id} 
            className="p-4 border border-gray-200 rounded-md hover:border-primary-300 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center justify-between mb-2">
              <div className={`text-lg ${
                plan.trackType === "Medical" ? "text-primary-600" :
                plan.trackType === "Reading" ? "text-secondary-500" :
                plan.trackType === "Skills" ? "text-green-500" :
                plan.trackType === "Engineering" ? "text-purple-600" :
                "text-gray-600"
              }`}>
                <i className={typeof plan.icon === 'string' ? plan.icon : 'ri-book-open-line'}></i>
              </div>
              <span className={`px-2 py-1 ${
                plan.trackType === "Medical" ? "bg-blue-100 text-blue-700" :
                plan.trackType === "Reading" ? "bg-indigo-100 text-indigo-700" :
                plan.trackType === "Skills" ? "bg-green-100 text-green-700" :
                plan.trackType === "Engineering" ? "bg-purple-100 text-purple-700" :
                "bg-gray-100 text-gray-700"
              } text-xs rounded-full`}>
                {plan.trackType}
              </span>
            </div>
            <h4 className="font-medium mb-1">{plan.title}</h4>
            <p className="text-sm text-gray-600">{plan.description}</p>
            <div className="mt-2 flex items-center justify-between">
              <span className="text-xs text-gray-500">
                Due: {format(new Date(plan.dueDate), "MMM d")}
              </span>
              <span className="text-xs font-medium text-primary-600">
                {plan.status === "pending" ? "Start →" : 
                 plan.status === "in-progress" ? "Continue →" : 
                 "Completed ✓"}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
