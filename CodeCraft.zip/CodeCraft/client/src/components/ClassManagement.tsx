import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, addHours } from "date-fns";
import { InsertEvent, Event, ClassRegistration } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Loader2, Users, Clock, Calendar as CalendarIcon, MapPin, Edit, Trash2,
  Plus, UserCheck, Info, CheckCircle, X as XCircle
} from "lucide-react";

export default function ClassManagement() {
  const [isCreating, setIsCreating] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [eventDate, setEventDate] = useState<Date>(new Date());
  const [eventEndDate, setEventEndDate] = useState<Date>(addHours(new Date(), 1));
  const queryClient = useQueryClient();

  // Fetch events
  const { 
    data: events,
    isLoading: eventsLoading
  } = useQuery({
    queryKey: ['/api/events'],
  });

  // Fetch registrations for the selected event
  const { 
    data: registrations,
    isLoading: registrationsLoading
  } = useQuery({
    queryKey: ['/api/events', selectedEvent?.id, 'registrations'],
    enabled: !!selectedEvent,
  });

  // Create event mutation
  const createEventMutation = useMutation({
    mutationFn: (newEvent: InsertEvent) => {
      return apiRequest('/api/events', 'POST', newEvent);
    },
    onSuccess: () => {
      toast({
        title: "Class created",
        description: "The class has been successfully created.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      setIsCreating(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create the class.",
        variant: "destructive",
      });
    }
  });

  // Update event mutation
  const updateEventMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Event> }) => {
      return apiRequest(`/api/events/${id}`, 'PATCH', data);
    },
    onSuccess: () => {
      toast({
        title: "Class updated",
        description: "The class has been successfully updated.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      setSelectedEvent(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update the class.",
        variant: "destructive",
      });
    }
  });

  // Delete event mutation
  const deleteEventMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/events/${id}`, 'DELETE');
    },
    onSuccess: () => {
      toast({
        title: "Class deleted",
        description: "The class has been successfully deleted.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      setSelectedEvent(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the class.",
        variant: "destructive",
      });
    }
  });

  // Update registration status mutation
  const updateRegistrationMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: { attended: boolean } }) => {
      return apiRequest(`/api/class-registrations/${id}`, 'PATCH', data);
    },
    onSuccess: () => {
      toast({
        title: "Attendance updated",
        description: "Student attendance has been marked.",
        variant: "default",
      });
      if (selectedEvent) {
        queryClient.invalidateQueries({ queryKey: ['/api/events', selectedEvent.id, 'registrations'] });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update attendance.",
        variant: "destructive",
      });
    }
  });

  // Handler for creating new event
  const handleCreateEvent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newEvent: InsertEvent = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      type: formData.get('type') as string,
      date: eventDate,
      endDate: eventEndDate,
      location: formData.get('location') as string,
      instructor: formData.get('instructor') as string,
      capacity: parseInt(formData.get('capacity') as string, 10) || null,
      status: 'scheduled',
      meetingLink: formData.get('meetingLink') as string,
      materials: []
    };
    
    createEventMutation.mutate(newEvent);
  };

  // Handler for updating an event
  const handleUpdateEvent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedEvent) return;
    
    const formData = new FormData(e.currentTarget);
    const updatedEvent: Partial<Event> = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      type: formData.get('type') as string,
      date: eventDate,
      endDate: eventEndDate,
      location: formData.get('location') as string,
      instructor: formData.get('instructor') as string,
      capacity: parseInt(formData.get('capacity') as string, 10) || null,
      status: formData.get('status') as string,
      meetingLink: formData.get('meetingLink') as string,
    };
    
    updateEventMutation.mutate({ id: selectedEvent.id, data: updatedEvent });
  };

  // Handler for marking attendance
  const handleMarkAttendance = (registrationId: number, attended: boolean) => {
    updateRegistrationMutation.mutate({
      id: registrationId,
      data: { attended }
    });
  };

  // Loading state
  if (eventsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-bold">Class Management</CardTitle>
              <CardDescription>Create and manage live classes and sessions</CardDescription>
            </div>
            <Button 
              onClick={() => {
                setIsCreating(true);
                setSelectedEvent(null);
              }}
              disabled={isCreating || !!selectedEvent}
            >
              <Plus className="w-4 h-4 mr-2" /> New Class
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="classes">
            <TabsList className="mb-4">
              <TabsTrigger value="classes">All Classes</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>
            
            <TabsContent value="classes">
              {events && events.length > 0 ? (
                <div className="space-y-4">
                  {events.map((event: Event) => (
                    <Card key={event.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-lg">{event.title}</h3>
                            <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                            
                            <div className="mt-2 space-y-1">
                              <div className="flex items-center text-sm text-gray-600">
                                <CalendarIcon className="w-4 h-4 mr-2" />
                                <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
                              </div>
                              <div className="flex items-center text-sm text-gray-600">
                                <Clock className="w-4 h-4 mr-2" />
                                <span>
                                  {format(new Date(event.date), 'h:mm a')} - 
                                  {event.endDate ? format(new Date(event.endDate), 'h:mm a') : 'TBD'}
                                </span>
                              </div>
                              {event.location && (
                                <div className="flex items-center text-sm text-gray-600">
                                  <MapPin className="w-4 h-4 mr-2" />
                                  <span>{event.location}</span>
                                </div>
                              )}
                              {event.instructor && (
                                <div className="flex items-center text-sm text-gray-600">
                                  <Users className="w-4 h-4 mr-2" />
                                  <span>Instructor: {event.instructor}</span>
                                </div>
                              )}
                            </div>
                            
                            <div className="flex mt-3 space-x-2">
                              <Badge variant={event.type === 'Live Class' ? 'default' : 'secondary'}>
                                {event.type}
                              </Badge>
                              <Badge variant={
                                event.status === 'scheduled' ? 'outline' :
                                event.status === 'in-progress' ? 'secondary' :
                                event.status === 'completed' ? 'default' : 'destructive'
                              }>
                                {event.status}
                              </Badge>
                              {event.capacity && (
                                <Badge variant="outline">
                                  {event.enrolledCount || 0} / {event.capacity} enrolled
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              size="icon"
                              onClick={() => {
                                setSelectedEvent(event);
                                setEventDate(new Date(event.date));
                                setEventEndDate(event.endDate ? new Date(event.endDate) : addHours(new Date(event.date), 1));
                                setIsCreating(false);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="icon"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => {
                                if (window.confirm('Are you sure you want to delete this class?')) {
                                  deleteEventMutation.mutate(event.id);
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-primary"
                              onClick={() => {
                                setSelectedEvent(event);
                              }}
                            >
                              <UserCheck className="w-4 h-4 mr-1" /> Attendance
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <Info className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium">No classes found</h3>
                  <p className="mt-1">Create a new class to get started</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="upcoming">
              {events && events.filter((e: Event) => new Date(e.date) >= new Date()).length > 0 ? (
                <div className="space-y-4">
                  {events
                    .filter((e: Event) => new Date(e.date) >= new Date())
                    .sort((a: Event, b: Event) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map((event: Event) => (
                      <Card key={event.id} className="overflow-hidden">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{event.title}</h3>
                              <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                              
                              <div className="mt-2 space-y-1">
                                <div className="flex items-center text-sm text-gray-600">
                                  <CalendarIcon className="w-4 h-4 mr-2" />
                                  <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
                                </div>
                                <div className="flex items-center text-sm text-gray-600">
                                  <Clock className="w-4 h-4 mr-2" />
                                  <span>
                                    {format(new Date(event.date), 'h:mm a')} - 
                                    {event.endDate ? format(new Date(event.endDate), 'h:mm a') : 'TBD'}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="flex mt-3 space-x-2">
                                <Badge variant="outline">
                                  {event.enrolledCount || 0} / {event.capacity || '∞'} enrolled
                                </Badge>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="icon"
                                onClick={() => {
                                  setSelectedEvent(event);
                                  setEventDate(new Date(event.date));
                                  setEventEndDate(event.endDate ? new Date(event.endDate) : addHours(new Date(event.date), 1));
                                  setIsCreating(false);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  No upcoming classes
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="past">
              {events && events.filter((e: Event) => new Date(e.date) < new Date()).length > 0 ? (
                <div className="space-y-4">
                  {events
                    .filter((e: Event) => new Date(e.date) < new Date())
                    .sort((a: Event, b: Event) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((event: Event) => (
                      <Card key={event.id} className="overflow-hidden">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{event.title}</h3>
                              <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                              
                              <div className="mt-2 space-y-1">
                                <div className="flex items-center text-sm text-gray-600">
                                  <CalendarIcon className="w-4 h-4 mr-2" />
                                  <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
                                </div>
                              </div>
                              
                              <div className="flex mt-3 space-x-2">
                                <Badge variant="secondary">
                                  {event.status}
                                </Badge>
                                <Badge variant="outline">
                                  {event.enrolledCount || 0} students enrolled
                                </Badge>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-primary"
                                onClick={() => {
                                  setSelectedEvent(event);
                                }}
                              >
                                <UserCheck className="w-4 h-4 mr-1" /> Attendance
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  No past classes
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Event creation form */}
      {isCreating && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold">Create New Class</CardTitle>
            <CardDescription>
              Fill in the details for the new class or session
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form id="createForm" onSubmit={handleCreateEvent}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Class Title*</Label>
                    <Input id="title" name="title" required />
                  </div>
                  <div>
                    <Label htmlFor="description">Description*</Label>
                    <Textarea id="description" name="description" required />
                  </div>
                  <div>
                    <Label htmlFor="type">Type*</Label>
                    <RadioGroup defaultValue="Live Class" name="type" className="flex space-x-4 mt-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Live Class" id="type-live" />
                        <Label htmlFor="type-live">Live Class</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Workshop" id="type-workshop" />
                        <Label htmlFor="type-workshop">Workshop</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Seminar" id="type-seminar" />
                        <Label htmlFor="type-seminar">Seminar</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  <div>
                    <Label htmlFor="instructor">Instructor</Label>
                    <Input id="instructor" name="instructor" />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label>Date and Time*</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {format(eventDate, "PPP")}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={eventDate}
                            onSelect={(date) => date && setEventDate(date)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <Input
                        type="time"
                        value={format(eventDate, "HH:mm")}
                        onChange={(e) => {
                          const [hours, minutes] = e.target.value.split(':');
                          const newDate = new Date(eventDate);
                          newDate.setHours(parseInt(hours, 10), parseInt(minutes, 10));
                          setEventDate(newDate);
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>End Time</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {format(eventEndDate, "PPP")}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={eventEndDate}
                            onSelect={(date) => date && setEventEndDate(date)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <Input
                        type="time"
                        value={format(eventEndDate, "HH:mm")}
                        onChange={(e) => {
                          const [hours, minutes] = e.target.value.split(':');
                          const newDate = new Date(eventEndDate);
                          newDate.setHours(parseInt(hours, 10), parseInt(minutes, 10));
                          setEventEndDate(newDate);
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="location">Location (Optional)</Label>
                    <Input id="location" name="location" placeholder="Virtual/Online or physical location" />
                  </div>
                  <div>
                    <Label htmlFor="capacity">Capacity (Optional)</Label>
                    <Input id="capacity" name="capacity" type="number" />
                  </div>
                  <div>
                    <Label htmlFor="meetingLink">Meeting Link (Optional)</Label>
                    <Input id="meetingLink" name="meetingLink" />
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
            <Button 
              type="submit"
              form="createForm"
              disabled={createEventMutation.isPending}
            >
              {createEventMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create Class
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Event edit form */}
      {selectedEvent && !isCreating && !registrations && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold">Edit Class</CardTitle>
            <CardDescription>
              Update the details for this class or session
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form id="editForm" onSubmit={handleUpdateEvent}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="edit-title">Class Title*</Label>
                    <Input 
                      id="edit-title" 
                      name="title" 
                      defaultValue={selectedEvent.title} 
                      required 
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-description">Description*</Label>
                    <Textarea 
                      id="edit-description" 
                      name="description" 
                      defaultValue={selectedEvent.description} 
                      required 
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-type">Type*</Label>
                    <RadioGroup 
                      defaultValue={selectedEvent.type} 
                      name="type" 
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Live Class" id="edit-type-live" />
                        <Label htmlFor="edit-type-live">Live Class</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Workshop" id="edit-type-workshop" />
                        <Label htmlFor="edit-type-workshop">Workshop</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Seminar" id="edit-type-seminar" />
                        <Label htmlFor="edit-type-seminar">Seminar</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  <div>
                    <Label htmlFor="edit-instructor">Instructor</Label>
                    <Input 
                      id="edit-instructor" 
                      name="instructor" 
                      defaultValue={selectedEvent.instructor || ''} 
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-status">Status</Label>
                    <RadioGroup 
                      defaultValue={selectedEvent.status || 'scheduled'} 
                      name="status" 
                      className="flex flex-wrap gap-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="scheduled" id="edit-status-scheduled" />
                        <Label htmlFor="edit-status-scheduled">Scheduled</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="in-progress" id="edit-status-progress" />
                        <Label htmlFor="edit-status-progress">In Progress</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="completed" id="edit-status-completed" />
                        <Label htmlFor="edit-status-completed">Completed</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="cancelled" id="edit-status-cancelled" />
                        <Label htmlFor="edit-status-cancelled">Cancelled</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label>Date and Time*</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {format(eventDate, "PPP")}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={eventDate}
                            onSelect={(date) => date && setEventDate(date)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <Input
                        type="time"
                        value={format(eventDate, "HH:mm")}
                        onChange={(e) => {
                          const [hours, minutes] = e.target.value.split(':');
                          const newDate = new Date(eventDate);
                          newDate.setHours(parseInt(hours, 10), parseInt(minutes, 10));
                          setEventDate(newDate);
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>End Time</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {format(eventEndDate, "PPP")}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={eventEndDate}
                            onSelect={(date) => date && setEventEndDate(date)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <Input
                        type="time"
                        value={format(eventEndDate, "HH:mm")}
                        onChange={(e) => {
                          const [hours, minutes] = e.target.value.split(':');
                          const newDate = new Date(eventEndDate);
                          newDate.setHours(parseInt(hours, 10), parseInt(minutes, 10));
                          setEventEndDate(newDate);
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="edit-location">Location (Optional)</Label>
                    <Input 
                      id="edit-location" 
                      name="location" 
                      defaultValue={selectedEvent.location || ''} 
                      placeholder="Virtual/Online or physical location" 
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-capacity">Capacity (Optional)</Label>
                    <Input 
                      id="edit-capacity" 
                      name="capacity" 
                      type="number" 
                      defaultValue={selectedEvent.capacity || ''} 
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-meetingLink">Meeting Link (Optional)</Label>
                    <Input 
                      id="edit-meetingLink" 
                      name="meetingLink" 
                      defaultValue={selectedEvent.meetingLink || ''} 
                    />
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setSelectedEvent(null)}>Cancel</Button>
            <Button 
              type="submit"
              form="editForm"
              disabled={updateEventMutation.isPending}
            >
              {updateEventMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Update Class
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Attendance Management */}
      {selectedEvent && registrations && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl font-bold">Class Attendance</CardTitle>
                <CardDescription>
                  {selectedEvent.title} - {format(new Date(selectedEvent.date), 'MMM d, yyyy')}
                </CardDescription>
              </div>
              <Button variant="outline" onClick={() => setSelectedEvent(null)}>Back</Button>
            </div>
          </CardHeader>
          <CardContent>
            {registrationsLoading ? (
              <div className="flex justify-center items-center h-40">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : registrations && registrations.length > 0 ? (
              <div className="space-y-4">
                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Student ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Registration Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Attendance
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {registrations.map((registration: ClassRegistration) => (
                        <tr key={registration.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              User #{registration.userId}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {format(new Date(registration.registeredAt), 'MMM d, yyyy')}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              registration.attended ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {registration.attended ? 'Present' : 'Not Marked'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button
                              variant={registration.attended ? "outline" : "default"}
                              size="sm"
                              className={registration.attended ? "mr-2 bg-gray-100" : "mr-2"}
                              onClick={() => handleMarkAttendance(registration.id, !registration.attended)}
                              disabled={updateRegistrationMutation.isPending}
                            >
                              {registration.attended ? (
                                <>
                                  <XCircle className="w-4 h-4 mr-1" /> Mark Absent
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="w-4 h-4 mr-1" /> Mark Present
                                </>
                              )}
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Info className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium">No registrations found</h3>
                <p className="mt-1">No students have registered for this class yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}