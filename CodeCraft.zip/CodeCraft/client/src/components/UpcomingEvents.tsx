import { format } from "date-fns";
import { Event } from "@shared/schema";

interface UpcomingEventsProps {
  events: Event[];
}

export default function UpcomingEvents({ events }: UpcomingEventsProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-5">
        <h3 className="text-lg font-semibold mb-3">Upcoming Events</h3>
        <ul className="space-y-3">
          {events.map((event) => (
            <li key={event.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-10 h-10 rounded-full ${event.iconBackground} flex items-center justify-center`}>
                <i className={`${event.icon} ${event.type === 'live' ? 'text-primary-600' : event.type === 'reading' ? 'text-green-600' : 'text-amber-600'}`}></i>
              </div>
              <div>
                <p className="text-sm font-medium">{event.title}</p>
                <p className="text-xs text-gray-500">
                  {format(new Date(event.date), "EEEE, h:mm a")}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <div className="bg-gray-50 px-5 py-3 border-t">
        <a href="#" className="text-primary-600 text-sm font-medium hover:text-primary-700">
          View full schedule →
        </a>
      </div>
    </div>
  );
}
