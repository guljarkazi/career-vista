import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function AppSettings() {
  const [theme, setTheme] = useState("light");
  const [fontSize, setFontSize] = useState("medium");
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [assignmentReminders, setAssignmentReminders] = useState(true);
  const [liveClassAlerts, setLiveClassAlerts] = useState(true);
  const [marketingComms, setMarketingComms] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);

  return (
    <div className="mt-4">
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-6">Settings</h2>
          
          <div className="space-y-8">
            {/* Account Settings */}
            <section>
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <i className="ri-shield-user-line mr-2 text-primary-600"></i>
                Account Settings
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md hover:border-gray-300">
                  <div>
                    <h4 className="font-medium">Change Password</h4>
                    <p className="text-sm text-gray-600">Update your account password</p>
                  </div>
                  <Button variant="ghost" className="text-primary-600 hover:text-primary-700 font-medium">
                    Change
                  </Button>
                </div>
                
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md hover:border-gray-300">
                  <div>
                    <h4 className="font-medium">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-600">Add an extra layer of security</p>
                  </div>
                  <Button variant="ghost" className="text-primary-600 hover:text-primary-700 font-medium">
                    Enable
                  </Button>
                </div>
                
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md hover:border-gray-300">
                  <div>
                    <h4 className="font-medium">Login History</h4>
                    <p className="text-sm text-gray-600">View your recent login activity</p>
                  </div>
                  <Button variant="ghost" className="text-primary-600 hover:text-primary-700 font-medium">
                    View
                  </Button>
                </div>
              </div>
            </section>
            
            {/* Notification Settings */}
            <section>
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <i className="ri-notification-line mr-2 text-primary-600"></i>
                Notification Preferences
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md">
                  <div>
                    <h4 className="font-medium">Email Notifications</h4>
                    <p className="text-sm text-gray-600">Receive updates about your courses</p>
                  </div>
                  <Switch 
                    checked={emailNotifications} 
                    onCheckedChange={setEmailNotifications} 
                  />
                </div>
                
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md">
                  <div>
                    <h4 className="font-medium">Assignment Reminders</h4>
                    <p className="text-sm text-gray-600">Get notified about upcoming deadlines</p>
                  </div>
                  <Switch 
                    checked={assignmentReminders} 
                    onCheckedChange={setAssignmentReminders} 
                  />
                </div>
                
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md">
                  <div>
                    <h4 className="font-medium">Live Class Alerts</h4>
                    <p className="text-sm text-gray-600">Receive reminders before live classes</p>
                  </div>
                  <Switch 
                    checked={liveClassAlerts} 
                    onCheckedChange={setLiveClassAlerts} 
                  />
                </div>
                
                <div className="flex justify-between items-center p-4 border border-gray-200 rounded-md">
                  <div>
                    <h4 className="font-medium">Marketing Communications</h4>
                    <p className="text-sm text-gray-600">Receive news and special offers</p>
                  </div>
                  <Switch 
                    checked={marketingComms} 
                    onCheckedChange={setMarketingComms} 
                  />
                </div>
              </div>
            </section>
            
            {/* Display Settings */}
            <section>
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <i className="ri-eye-line mr-2 text-primary-600"></i>
                Display Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="theme" className="block text-sm font-medium text-gray-700 mb-1">Theme</Label>
                  <Select value={theme} onValueChange={setTheme}>
                    <SelectTrigger id="theme" className="w-full md:w-1/3">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light Mode</SelectItem>
                      <SelectItem value="dark">Dark Mode</SelectItem>
                      <SelectItem value="system">System Default</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="fontSize" className="block text-sm font-medium text-gray-700 mb-1">Font Size</Label>
                  <Select value={fontSize} onValueChange={setFontSize}>
                    <SelectTrigger id="fontSize" className="w-full md:w-1/3">
                      <SelectValue placeholder="Select font size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="reduceMotion" 
                    checked={reduceMotion} 
                    onCheckedChange={setReduceMotion} 
                  />
                  <Label htmlFor="reduceMotion" className="text-sm text-gray-600">
                    Reduce animations and motion effects
                  </Label>
                </div>
              </div>
            </section>
            
            {/* Account Actions */}
            <section>
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <i className="ri-logout-box-line mr-2 text-red-600"></i>
                Account Actions
              </h3>
              <div className="space-y-4">
                <Button variant="destructive" className="text-white bg-red-600 hover:bg-red-700">
                  Sign Out
                </Button>
                <Button variant="link" className="text-red-600 hover:text-red-700 text-sm p-0 h-auto">
                  Deactivate Account
                </Button>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
