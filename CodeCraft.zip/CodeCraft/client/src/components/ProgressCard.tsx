import { Track } from "@shared/schema";
import { cn } from "@/lib/utils";

interface ProgressCardProps {
  tracks: Track[];
  className?: string;
}

export default function ProgressCard({ tracks, className }: ProgressCardProps) {
  return (
    <div className={cn("bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden", className)}>
      <div className="p-5">
        <h3 className="text-lg font-semibold mb-4">This Week's Progress</h3>
        
        <div className="space-y-4">
          {tracks.map((track) => (
            <div key={track.id}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{track.name}</span>
                <span className="text-sm text-gray-500">{track.progress}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${
                    track.name === "Medical Track" ? "bg-primary-600" :
                    track.name === "Engineering Track" ? "bg-secondary-500" :
                    track.name === "Life Skills Track" ? "bg-green-500" :
                    track.name === "IAS Track" ? "bg-amber-500" :
                    "bg-purple-500"
                  }`}
                  style={{ width: `${track.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-gray-50 px-5 py-3 border-t">
        <a href="#" className="text-primary-600 text-sm font-medium hover:text-primary-700">
          View detailed analytics →
        </a>
      </div>
    </div>
  );
}
