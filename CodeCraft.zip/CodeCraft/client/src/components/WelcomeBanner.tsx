import { Button } from "@/components/ui/button";

interface WelcomeBannerProps {
  userName: string;
}

export default function WelcomeBanner({ userName }: WelcomeBannerProps) {
  return (
    <div className="rounded-lg text-white mb-6 shadow-md overflow-hidden relative">
      <img 
        src="/images/education-banner.svg" 
        alt="Education Banner" 
        className="w-full h-auto object-cover"
      />
      <div className="absolute inset-0 flex items-center">
        <div className="p-6 md:flex md:items-center md:justify-between w-full">
          <div className="md:flex-1 z-10">
            <h2 className="text-3xl font-bold mb-2 drop-shadow-md">Welcome back, {userName}!</h2>
            <p className="opacity-90 text-lg drop-shadow-md">Continue your learning journey where you left off.</p>
          </div>
          <div className="mt-4 md:mt-0 z-10">
            <Button variant="secondary" className="bg-white text-primary-600 hover:bg-gray-100 font-semibold shadow-md">
              Resume Learning
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
