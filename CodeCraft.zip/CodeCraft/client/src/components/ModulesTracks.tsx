import { useState } from "react";
import { Track } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ModulesTracksProps {
  tracks: Track[];
}

export default function ModulesTracks({ tracks }: ModulesTracksProps) {
  const [filter, setFilter] = useState("all");

  const filteredTracks = tracks.filter(track => {
    if (filter === "all") return true;
    if (filter === "active") return (track.progress || 0) > 0 && (track.progress || 0) < 100;
    if (filter === "completed") return (track.progress || 0) === 100;
    return true;
  });

  return (
    <div className="mt-4 space-y-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xl font-semibold">Your Learning Tracks</h2>
        <div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter tracks" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tracks</SelectItem>
              <SelectItem value="active">Active Only</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTracks.map((track) => (
          <div key={track.id} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className={`h-36 ${track.backgroundColor} relative`}>
              <img 
                src={
                  track.name === "Medical Track" ? "/images/medical.svg" :
                  track.name === "Engineering Track" ? "/images/engineering.svg" :
                  track.name === "IAS Preparation" ? "/images/ias.svg" :
                  track.name === "Future Tech" ? "/images/future-tech.svg" :
                  "/images/life-skills.svg"
                }
                alt={track.name} 
                className="w-full h-full object-contain"
              />
              <div className="absolute inset-0 p-5 flex flex-col justify-end">
                {(track.featured || track.isNew) && (
                  <span className="bg-white/20 text-white px-2 py-1 rounded text-xs backdrop-blur-sm inline-block w-max">
                    {track.featured ? "Featured" : "New"}
                  </span>
                )}
                <h3 className="text-white text-xl font-bold mt-1 drop-shadow-md">{track.name}</h3>
              </div>
            </div>
            <div className="p-5">
              <div className="mb-3">
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Progress</span>
                  <span>{track.progress || 0}%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      track.name === "Medical Track" ? "bg-primary-600" :
                      track.name === "Engineering Track" ? "bg-purple-600" :
                      track.name === "IAS Preparation" ? "bg-amber-500" :
                      track.name === "Future Tech" ? "bg-cyan-500" :
                      "bg-green-500"
                    }`}
                    style={{ width: `${track.progress || 0}%` }}
                  ></div>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-4">{track.description}</p>
              <div className="flex justify-between">
                <Button 
                  className={
                    track.name === "Medical Track" ? "bg-primary-600 hover:bg-primary-700" :
                    track.name === "Engineering Track" ? "bg-purple-600 hover:bg-purple-700" :
                    track.name === "IAS Preparation" ? "bg-amber-500 hover:bg-amber-600" :
                    track.name === "Future Tech" ? "bg-cyan-600 hover:bg-cyan-700" :
                    "bg-green-600 hover:bg-green-700"
                  }
                >
                  Continue
                </Button>
                <Button variant="outline" className="text-gray-600 hover:text-gray-800 px-3">
                  <i className="ri-information-line"></i>
                </Button>
              </div>
            </div>
          </div>
        ))}
        
        {/* Explore More Card */}
        <div className="border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center p-8 text-center hover:bg-gray-50 transition-colors cursor-pointer">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
            <i className="ri-add-line text-2xl text-gray-500"></i>
          </div>
          <h3 className="font-medium text-gray-900 mb-1">Explore New Tracks</h3>
          <p className="text-sm text-gray-600">Discover more career paths and learning opportunities</p>
        </div>
      </div>
    </div>
  );
}
