import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import ClassManagement from "./ClassManagement";

const progressData = [
  { name: "Curriculum", progress: 90 },
  { name: "Modules", progress: 85 },
  { name: "Book Summaries", progress: 75 },
  { name: "Website/App", progress: 65 },
  { name: "Marketing Plan", progress: 40 },
  { name: "Funding", progress: 30 },
  { name: "Interest & Aptitude Test", progress: 70 },
];

export default function CareerVistaDashboard() {
  const [studentName, setStudentName] = useState("");

  const startTest = () => {
    window.open("https://forms.gle/qgU9hP6xwr6F4nTQ7", "_blank");
  };

  const viewTestResults = () => {
    window.open("https://docs.google.com/spreadsheets/d/1IelB1UZ9vOyRBfWTDgeCDkDe0PbRcb39XbxiAZKts-A/edit?usp=sharing", "_blank");
  };

  const viewEvaluationReport = () => {
    window.open("https://docs.google.com/document/d/1oOVvT8rEnJ53nJHa0lqq2J07abLPOdz-HWIIB8uHPtI/edit?usp=sharing", "_blank");
  };

  const handleGenerateReport = () => {
    const reportUrl = `https://docs.google.com/document/d/1oOVvT8rEnJ53nJHa0lqq2J07abLPOdz-HWIIB8uHPtI/edit?usp=sharing&student=${encodeURIComponent(studentName)}`;
    window.open(reportUrl, "_blank");
  };

  const automateReports = () => {
    window.open("https://script.google.com/home", "_blank");
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="mb-6 rounded-lg overflow-hidden shadow-md relative">
        <img 
          src="/images/dashboard-header.svg" 
          alt="Dashboard Header" 
          className="w-full"
        />
        <div className="absolute inset-0 flex justify-between items-center px-6">
          <h1 className="text-3xl font-bold text-white drop-shadow-md">Career Vista Project Dashboard</h1>
          <div 
            className="px-4 py-2 bg-white text-primary-800 rounded-md hover:bg-gray-100 transition-colors cursor-pointer shadow-md font-medium"
            onClick={() => window.location.href = "/"}>
            Return to Student Portal
          </div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="flex justify-center space-x-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="charts">Progress Chart</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="classes">Class Management</TabsTrigger>
          <TabsTrigger value="students">Student Evaluation</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Summary</h2>
              <ul className="list-disc list-inside">
                <li>🎯 Total Project Stages: 7</li>
                <li>✅ Completed: Curriculum, Modules, Book Summaries (partially)</li>
                <li>🚧 In Progress: Website/App, Marketing Plan, Funding, Interest & Aptitude Test</li>
              </ul>
              <div className="mt-6 flex flex-wrap justify-center gap-4">
                <Button onClick={startTest}>Start Interest & Aptitude Test</Button>
                <Button variant="secondary" onClick={viewTestResults}>View Test Results</Button>
                <Button variant="outline" onClick={viewEvaluationReport}>View Evaluation Report</Button>
                <Button variant="default" onClick={automateReports}>Automate Report System</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="charts">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Project Progress</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={progressData}>
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="progress" fill="#4f46e5" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {progressData.map((item) => (
              <Card key={item.name}>
                <CardContent className="p-4">
                  <div className="flex justify-between mb-2">
                    <h3 className="font-semibold text-lg">{item.name}</h3>
                    <span>{item.progress}%</span>
                  </div>
                  <Progress value={item.progress} />
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="classes">
          <ClassManagement />
        </TabsContent>

        <TabsContent value="students">
          <Card>
            <CardContent className="space-y-4 p-6">
              <h2 className="text-xl font-semibold">Student Profile Evaluation</h2>
              <div className="space-y-2">
                <Label htmlFor="student-name">Student Name</Label>
                <Input id="student-name" placeholder="Enter student name" value={studentName} onChange={(e) => setStudentName(e.target.value)} />
              </div>
              <div className="flex gap-4 pt-4">
                <Button onClick={handleGenerateReport}>Generate Evaluation Report</Button>
                <Button variant="secondary" onClick={viewTestResults}>See All Results</Button>
                <Button variant="outline" onClick={viewEvaluationReport}>Download Sample Report</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}