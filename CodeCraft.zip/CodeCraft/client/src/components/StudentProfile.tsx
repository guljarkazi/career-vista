import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { User as UserIcon, Camera } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface StudentProfileProps {
  user: User;
}

export default function StudentProfile({ user }: StudentProfileProps) {
  const [formData, setFormData] = useState({
    fullName: user.fullName,
    grade: user.grade,
    phone: user.phone || "",
    email: user.email || "",
    parentName: user.parentName || "",
    relationship: user.relationship || "Mother",
    parentPhone: user.parentPhone || "",
    parentEmail: user.parentEmail || "",
    bio: user.bio || "",
  });
  
  const queryClient = useQueryClient();
  
  const updateProfileMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/users/${user.id}`, formData);
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/current-user"] });
    },
    onError: (error) => {
      toast({
        title: "Error updating profile",
        description: "Please try again later.",
        variant: "destructive",
      });
      console.error("Error updating profile:", error);
    }
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate();
  };

  return (
    <div className="mt-4">
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-6 sm:p-8">
          <h2 className="text-xl font-semibold mb-6">Student Profile</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="flex flex-col items-center">
                <div className="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center mb-4 relative">
                  <UserIcon className="h-12 w-12 text-gray-500" />
                  <button className="absolute bottom-0 right-0 bg-primary-600 text-white rounded-full p-2 shadow-md hover:bg-primary-700">
                    <Camera className="h-4 w-4" />
                  </button>
                </div>
                <h3 className="text-lg font-medium">{user.fullName}</h3>
                <p className="text-gray-600 text-sm mb-4">{user.grade} • Student ID: S2023-094</p>
                
                <div className="w-full bg-gray-100 rounded-lg p-4 text-center mb-4">
                  <p className="text-sm font-medium text-gray-600 mb-1">Joined Career Vista</p>
                  <p className="text-lg font-semibold">August 2023</p>
                </div>
                
                <div className="w-full space-y-2">
                  <Button variant="outline" className="w-full border border-gray-300 text-gray-700 flex items-center justify-center">
                    <i className="ri-file-download-line mr-1"></i> Download Progress Report
                  </Button>
                  <Button variant="outline" className="w-full border border-gray-300 text-gray-700 flex items-center justify-center">
                    <i className="ri-share-line mr-1"></i> Share Profile
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                      <Input 
                        type="text" 
                        id="fullName" 
                        value={formData.fullName} 
                        onChange={handleChange}
                      />
                    </div>
                    <div>
                      <label htmlFor="grade" className="block text-sm font-medium text-gray-700 mb-1">Grade</label>
                      <Select value={formData.grade} onValueChange={(value) => handleSelectChange("grade", value)}>
                        <SelectTrigger id="grade">
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Grade 9">Grade 9</SelectItem>
                          <SelectItem value="Grade 10">Grade 10</SelectItem>
                          <SelectItem value="Grade 11">Grade 11</SelectItem>
                          <SelectItem value="Grade 12">Grade 12</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                      <Input 
                        type="tel" 
                        id="phone" 
                        placeholder="Enter phone number" 
                        value={formData.phone} 
                        onChange={handleChange}
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                      <Input 
                        type="email" 
                        id="email" 
                        value={formData.email} 
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Parent/Guardian Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="parentName" className="block text-sm font-medium text-gray-700 mb-1">Parent Name</label>
                      <Input 
                        type="text" 
                        id="parentName" 
                        value={formData.parentName} 
                        onChange={handleChange}
                      />
                    </div>
                    <div>
                      <label htmlFor="relationship" className="block text-sm font-medium text-gray-700 mb-1">Relationship</label>
                      <Select 
                        value={formData.relationship} 
                        onValueChange={(value) => handleSelectChange("relationship", value)}
                      >
                        <SelectTrigger id="relationship">
                          <SelectValue placeholder="Select relationship" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Mother">Mother</SelectItem>
                          <SelectItem value="Father">Father</SelectItem>
                          <SelectItem value="Guardian">Guardian</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label htmlFor="parentPhone" className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                      <Input 
                        type="tel" 
                        id="parentPhone" 
                        value={formData.parentPhone} 
                        onChange={handleChange}
                      />
                    </div>
                    <div>
                      <label htmlFor="parentEmail" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                      <Input 
                        type="email" 
                        id="parentEmail" 
                        value={formData.parentEmail} 
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Educational Interests</h3>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="careerInterests" className="block text-sm font-medium text-gray-700 mb-1">Career Interests</label>
                      <select 
                        id="careerInterests" 
                        multiple 
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" 
                        size={4}
                      >
                        <option selected={user.careerInterests?.includes("Medicine")}>Medicine</option>
                        <option selected={user.careerInterests?.includes("Engineering")}>Engineering</option>
                        <option selected={user.careerInterests?.includes("Civil Services")}>Civil Services</option>
                        <option selected={user.careerInterests?.includes("Data Science")}>Data Science</option>
                        <option selected={user.careerInterests?.includes("Design")}>Design</option>
                        <option selected={user.careerInterests?.includes("Business")}>Business</option>
                      </select>
                      <p className="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple options</p>
                    </div>
                    
                    <div>
                      <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">About Me</label>
                      <Textarea 
                        id="bio" 
                        rows={4} 
                        value={formData.bio} 
                        onChange={handleChange}
                        placeholder="Tell us a bit about yourself, your interests, and your goals..."
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-4">
                  <Button type="button" variant="outline" className="border border-gray-300 text-gray-700">
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-primary-600 hover:bg-primary-700"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
