import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { BookOpen, GraduationCap, Brain, Settings, User, BarChart2, Calendar } from "lucide-react";
import { User as UserType, Track, Skill, Event, WeeklyPlan, SkillActivity, ClassRegistration } from "@shared/schema";
import WelcomeBanner from "./WelcomeBanner";
import ProgressCard from "./ProgressCard";
import UpcomingEvents from "./UpcomingEvents";
import WeeklyPlanView from "./WeeklyPlan";
import ModulesTracks from "./ModulesTracks";
import SkillsDevelopment from "./SkillsDevelopment";
import StudentProfile from "./StudentProfile";
import AppSettings from "./AppSettings";
import ClassSchedule from "./ClassSchedule";

interface CareerVistaAppProps {
  user: UserType;
}

export default function CareerVistaApp({ user }: CareerVistaAppProps) {
  const [activeTab, setActiveTab] = useState("dashboard");
  
  const { data: tracks = [] } = useQuery<Track[]>({
    queryKey: ["/api/tracks"],
  });
  
  const { data: skills = [] } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });
  
  const { data: events = [] } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });
  
  const { data: weeklyPlans = [] } = useQuery<WeeklyPlan[]>({
    queryKey: [`/api/users/${user.id}/weekly-plans`],
  });
  
  const { data: skillActivities = [] } = useQuery<SkillActivity[]>({
    queryKey: [`/api/users/${user.id}/skill-activities`],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Bar */}
      <header className="bg-white border-b border-gray-200 py-3 sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary-600 rounded-md flex items-center justify-center text-white font-bold">
              CV
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary-600">Career Vista</h1>
              <p className="text-xs text-gray-500">Discover your path. Learn with purpose.</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="hidden md:flex items-center space-x-1">
              <span className="text-sm font-medium">{user.fullName}</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">{user.grade}</span>
            </div>
            <div className="flex items-center px-3 py-1 bg-blue-100 text-blue-800 text-xs rounded-md hover:bg-blue-200 transition-colors cursor-pointer"
                 onClick={() => window.location.href = "/dashboard"}>
              <BarChart2 className="h-3 w-3 mr-1" />
              <span>Admin Dashboard</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-4 sm:px-6 lg:px-8 space-y-6">
        {/* Welcome Banner */}
        <WelcomeBanner userName={user.fullName.split(" ")[0]} />

        {/* Main Tabs Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-6 gap-1 bg-transparent p-0 min-w-full border-b border-gray-200">
            <TabsTrigger 
              value="dashboard" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "dashboard" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <GraduationCap className="h-4 w-4" />
              <span>Dashboard</span>
            </TabsTrigger>
            <TabsTrigger 
              value="modules" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "modules" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <BookOpen className="h-4 w-4" />
              <span>Modules</span>
            </TabsTrigger>
            <TabsTrigger 
              value="classes" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "classes" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <Calendar className="h-4 w-4" />
              <span>Classes</span>
            </TabsTrigger>
            <TabsTrigger 
              value="skills" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "skills" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <Brain className="h-4 w-4" />
              <span>Skills</span>
            </TabsTrigger>
            <TabsTrigger 
              value="profile" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "profile" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <User className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className={`flex items-center space-x-1 rounded-t-lg ${activeTab === "settings" ? "border-b-2 border-primary-600 text-primary-600" : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"}`}
            >
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-4 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Progress Overview Card */}
              <ProgressCard tracks={tracks} className="md:col-span-2" />
              
              {/* Upcoming Events Card */}
              <UpcomingEvents events={events} />
            </div>
            
            {/* Weekly Plan Card */}
            <WeeklyPlanView plans={weeklyPlans} />
          </TabsContent>

          <TabsContent value="modules">
            <ModulesTracks tracks={tracks} />
          </TabsContent>
          
          <TabsContent value="classes">
            <ClassSchedule userId={user.id} />
          </TabsContent>

          <TabsContent value="skills">
            <SkillsDevelopment skills={skills} activities={skillActivities} userId={user.id} />
          </TabsContent>

          <TabsContent value="profile">
            <StudentProfile user={user} />
          </TabsContent>

          <TabsContent value="settings">
            <AppSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
