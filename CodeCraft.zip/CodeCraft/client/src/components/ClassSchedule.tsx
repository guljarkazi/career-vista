import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Event, ClassRegistration } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Users, Clock, Calendar as CalendarIcon, MapPin, CheckCircle, XCircle } from "lucide-react";

interface ClassScheduleProps {
  userId: number;
}

export default function ClassSchedule({ userId }: ClassScheduleProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list");
  const queryClient = useQueryClient();

  // Fetch upcoming events (classes)
  const { 
    data: events,
    isLoading: eventsLoading,
    error: eventsError
  } = useQuery({
    queryKey: ['/api/events/upcoming'],
    staleTime: 60000, // 1 minute
  });

  // Fetch user registrations
  const { 
    data: userRegistrations,
    isLoading: registrationsLoading,
    error: registrationsError
  } = useQuery({
    queryKey: ['/api/users', userId, 'class-registrations'],
    enabled: Boolean(userId),
  });

  // Register for class mutation
  const registerMutation = useMutation({
    mutationFn: (eventId: number) => {
      return apiRequest('/api/class-registrations', 'POST', {
        eventId,
        userId
      });
    },
    onSuccess: () => {
      toast({
        title: "Successfully registered",
        description: "You have been registered for this class.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users', userId, 'class-registrations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/events/upcoming'] });
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Failed to register for the class.",
        variant: "destructive",
      });
    }
  });

  // Cancel registration mutation
  const cancelMutation = useMutation({
    mutationFn: (registrationId: number) => {
      return apiRequest(`/api/class-registrations/${registrationId}`, 'DELETE');
    },
    onSuccess: () => {
      toast({
        title: "Registration cancelled",
        description: "Your registration has been cancelled.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users', userId, 'class-registrations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/events/upcoming'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to cancel registration.",
        variant: "destructive",
      });
    }
  });

  // Check if user is registered for a specific event
  const isRegistered = (eventId: number) => {
    if (!userRegistrations) return false;
    return userRegistrations.some((reg: ClassRegistration) => reg.eventId === eventId);
  };

  // Get the registration ID for a specific event
  const getRegistrationId = (eventId: number) => {
    if (!userRegistrations) return null;
    const registration = userRegistrations.find((reg: ClassRegistration) => reg.eventId === eventId);
    return registration ? registration.id : null;
  };

  // Handler for registering for a class
  const handleRegister = (eventId: number) => {
    registerMutation.mutate(eventId);
  };

  // Handler for cancelling a registration
  const handleCancelRegistration = (eventId: number) => {
    const registrationId = getRegistrationId(eventId);
    if (registrationId) {
      cancelMutation.mutate(registrationId);
    }
  };

  // Filter events by selected date
  const filteredEvents = events?.filter((event: Event) => {
    if (!selectedDate) return true;
    
    const eventDate = new Date(event.date);
    return (
      eventDate.getDate() === selectedDate.getDate() &&
      eventDate.getMonth() === selectedDate.getMonth() &&
      eventDate.getFullYear() === selectedDate.getFullYear()
    );
  });

  // Loading state
  if (eventsLoading || registrationsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  // Error state
  if (eventsError || registrationsError) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-destructive">
            <p>Failed to load class schedule. Please try again later.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <Calendar className="w-5 h-5 mr-2" />
          Live Class Schedule
        </CardTitle>
        <CardDescription>
          Register for upcoming live classes and interactive sessions
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={viewMode} onValueChange={(value) => setViewMode(value as "list" | "calendar")}>
          <TabsList className="mb-4">
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          </TabsList>
          
          <TabsContent value="calendar">
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
              <div className="md:col-span-3">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="border rounded-md"
                />
              </div>
              <div className="md:col-span-4">
                <h3 className="text-md font-medium mb-2">
                  {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : 'All Events'}
                </h3>
                {filteredEvents && filteredEvents.length > 0 ? (
                  <div className="space-y-4">
                    {filteredEvents.map((event: Event) => (
                      <EventCard 
                        key={event.id} 
                        event={event} 
                        isRegistered={isRegistered(event.id)} 
                        onRegister={() => handleRegister(event.id)}
                        onCancel={() => handleCancelRegistration(event.id)}
                        isPending={registerMutation.isPending || cancelMutation.isPending}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    No classes scheduled for this date
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="list">
            <div className="space-y-4">
              {events && events.length > 0 ? (
                events.map((event: Event) => (
                  <EventCard 
                    key={event.id} 
                    event={event}
                    isRegistered={isRegistered(event.id)}
                    onRegister={() => handleRegister(event.id)}
                    onCancel={() => handleCancelRegistration(event.id)}
                    isPending={registerMutation.isPending || cancelMutation.isPending}
                  />
                ))
              ) : (
                <div className="text-center py-6 text-gray-500">
                  No upcoming classes scheduled
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex flex-col items-start space-y-2 text-sm text-gray-500">
        <p>• Classes are held virtually unless otherwise specified</p>
        <p>• You can cancel your registration up to 24 hours before the class</p>
        <p>• Recordings will be available for registered students after the session</p>
      </CardFooter>
    </Card>
  );
}

interface EventCardProps {
  event: Event;
  isRegistered: boolean;
  onRegister: () => void;
  onCancel: () => void;
  isPending: boolean;
}

function EventCard({ event, isRegistered, onRegister, onCancel, isPending }: EventCardProps) {
  return (
    <Card className={`border ${isRegistered ? 'border-primary/50 bg-primary/5' : ''}`}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-semibold text-lg">{event.title}</h3>
            <p className="text-sm text-gray-600 mt-1">{event.description}</p>
            
            <div className="mt-2 space-y-1">
              <div className="flex items-center text-sm text-gray-600">
                <CalendarIcon className="w-4 h-4 mr-2" />
                <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Clock className="w-4 h-4 mr-2" />
                <span>{format(new Date(event.date), 'h:mm a')} - {event.endDate ? format(new Date(event.endDate), 'h:mm a') : 'TBD'}</span>
              </div>
              {event.location && (
                <div className="flex items-center text-sm text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>{event.location}</span>
                </div>
              )}
              {event.instructor && (
                <div className="flex items-center text-sm text-gray-600">
                  <Users className="w-4 h-4 mr-2" />
                  <span>Instructor: {event.instructor}</span>
                </div>
              )}
            </div>
            
            <div className="flex mt-3 space-x-2">
              <Badge variant={event.type === 'Live Class' ? 'default' : 'secondary'}>
                {event.type}
              </Badge>
              {event.capacity && (
                <Badge variant="outline">
                  {event.enrolledCount || 0} / {event.capacity} enrolled
                </Badge>
              )}
              {isRegistered && (
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" /> Registered
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="px-4 py-3 bg-gray-50 flex justify-end">
        {isRegistered ? (
          <Button 
            variant="outline" 
            className="text-red-600 border-red-200 hover:bg-red-50"
            onClick={onCancel}
            disabled={isPending}
          >
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Cancel Registration
          </Button>
        ) : (
          <Button 
            onClick={onRegister}
            disabled={isPending || (event.capacity !== null && event.enrolledCount !== null && event.enrolledCount >= event.capacity)}
          >
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {event.capacity !== null && event.enrolledCount !== null && event.enrolledCount >= event.capacity ? 
              'Class Full' : 'Register Now'}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}