import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Skill, SkillActivity } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SkillsDevelopmentProps {
  skills: Skill[];
  activities: SkillActivity[];
  userId: number;
}

export default function SkillsDevelopment({ skills, activities, userId }: SkillsDevelopmentProps) {
  const [response, setResponse] = useState("");
  const queryClient = useQueryClient();
  
  const currentActivity = activities.length > 0 ? activities[0] : null;
  
  const submitMutation = useMutation({
    mutationFn: async () => {
      if (!currentActivity) return null;
      return apiRequest("POST", `/api/skill-activities/${currentActivity.id}/submit`, { response });
    },
    onSuccess: () => {
      toast({
        title: "Response submitted successfully",
        description: "Your response has been recorded.",
      });
      setResponse("");
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/skill-activities`] });
    },
    onError: (error) => {
      toast({
        title: "Error submitting response",
        description: "Please try again later.",
        variant: "destructive",
      });
      console.error("Error submitting skill activity response:", error);
    }
  });

  const handleSubmit = () => {
    if (!response.trim()) {
      toast({
        title: "Empty response",
        description: "Please write your response before submitting.",
        variant: "destructive",
      });
      return;
    }
    
    submitMutation.mutate();
  };

  return (
    <div className="mt-4 space-y-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xl font-semibold">Skills Development</h2>
        <div>
          <Button variant="outline" className="text-sm border border-gray-300 text-gray-700">
            View History
          </Button>
        </div>
      </div>
      
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-lg font-medium mb-4">Weekly Creative Thinking Challenge</h3>
        {currentActivity && (
          <>
            <div className="mb-4 p-4 bg-gray-50 rounded-md border border-gray-200">
              <p className="text-gray-700 mb-2"><strong>Prompt:</strong> {currentActivity.prompt}</p>
              <p className="text-sm text-gray-500">Take your time to think deeply about this challenge. Consider different perspectives and be as detailed as possible in your response.</p>
            </div>
            
            <div className="mb-4">
              <label htmlFor="response" className="block text-sm font-medium text-gray-700 mb-1">Your Response</label>
              <Textarea 
                id="response" 
                rows={6} 
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                placeholder="Write your response to this week's creative challenge..."
                disabled={submitMutation.isPending || currentActivity.status === "submitted"}
              />
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 justify-end">
              <Button 
                variant="outline" 
                className="order-2 sm:order-1 border border-gray-300 text-gray-700"
                disabled={submitMutation.isPending || currentActivity.status === "submitted"}
              >
                Save as Draft
              </Button>
              <Button 
                className="order-1 sm:order-2 bg-primary-600 hover:bg-primary-700"
                onClick={handleSubmit}
                disabled={submitMutation.isPending || currentActivity.status === "submitted"}
              >
                {submitMutation.isPending ? "Submitting..." : 
                 currentActivity.status === "submitted" ? "Submitted" : "Submit Response"}
              </Button>
            </div>
          </>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {skills.map((skill) => (
          <div key={skill.id} className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
            <div className="flex items-center mb-4">
              <div className={`w-10 h-10 rounded-full bg-${skill.iconColor === "text-primary-600" ? "blue" : skill.iconColor === "text-green-600" ? "green" : "purple"}-100 flex items-center justify-center mr-3`}>
                <i className={`${skill.icon} ${skill.iconColor}`}></i>
              </div>
              <h3 className="text-lg font-medium">{skill.name}</h3>
            </div>
            <div className="mb-3">
              <div className="flex justify-between text-sm mb-1">
                <span className="font-medium">Skill Level</span>
                <span>{skill.level}</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${
                    skill.iconColor === "text-primary-600" ? "bg-primary-600" :
                    skill.iconColor === "text-green-600" ? "bg-green-500" :
                    "bg-purple-500"
                  }`}
                  style={{ width: `${skill.progress}%` }}
                ></div>
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-4">{skill.description}</p>
            <Button 
              variant="outline" 
              className={`w-full ${
                skill.iconColor === "text-primary-600" ? "bg-primary-50 text-primary-700 border-primary-200 hover:bg-primary-100" :
                skill.iconColor === "text-green-600" ? "bg-green-50 text-green-700 border-green-200 hover:bg-green-100" :
                "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
              }`}
            >
              View Activities
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
