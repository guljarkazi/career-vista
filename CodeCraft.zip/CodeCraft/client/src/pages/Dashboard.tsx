import CareerVistaDashboard from "@/components/CareerVistaDashboard";

export default function Dashboard() {
  return <CareerVistaDashboard />;
}