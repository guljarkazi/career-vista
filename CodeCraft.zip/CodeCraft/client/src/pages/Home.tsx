import { useQuery } from "@tanstack/react-query";
import CareerVistaApp from "@/components/CareerVistaApp";
import { User } from "@shared/schema";

export default function Home() {
  const { data: currentUser, isLoading, error } = useQuery<User>({
    queryKey: ["/api/current-user"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-lg text-gray-600">Loading Career Vista...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-lg shadow-md p-6 max-w-md w-full">
          <h1 className="text-xl font-bold text-red-600 mb-2">Error</h1>
          <p className="text-gray-700">
            We encountered an error while loading your profile. Please try again later.
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 bg-primary-600 text-white px-4 py-2 rounded-md hover:bg-primary-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return <CareerVistaApp user={currentUser!} />;
}
