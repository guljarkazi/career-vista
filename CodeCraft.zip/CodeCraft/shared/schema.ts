import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  grade: text("grade").notNull(),
  email: text("email"),
  phone: text("phone"),
  parentName: text("parent_name"),
  parentEmail: text("parent_email"),
  parentPhone: text("parent_phone"),
  relationship: text("relationship"),
  bio: text("bio"),
  careerInterests: text("career_interests").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  progress: integer("progress").default(0),
  backgroundColor: text("background_color"),
  image: text("image"),
  featured: boolean("featured").default(false),
  isNew: boolean("is_new").default(false),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  level: text("level").notNull(),
  progress: integer("progress").default(0),
  icon: text("icon"),
  iconColor: text("icon_color"),
});

export const skillActivities = pgTable("skill_activities", {
  id: serial("id").primaryKey(),
  skillId: integer("skill_id").notNull(),
  userId: integer("user_id").notNull(),
  prompt: text("prompt").notNull(),
  response: text("response"),
  status: text("status").default("pending"),
  submittedAt: timestamp("submitted_at"),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  endDate: timestamp("end_date"),
  type: text("type").notNull(),
  location: text("location"),
  instructor: text("instructor"),
  capacity: integer("capacity"),
  enrolledCount: integer("enrolled_count").default(0),
  status: text("status").default("scheduled"), // scheduled, in-progress, completed, cancelled
  meetingLink: text("meeting_link"),
  recordingLink: text("recording_link"),
  materials: json("materials").$type<string[]>(),
  icon: text("icon"),
  iconBackground: text("icon_background"),
});

export const weeklyPlans = pgTable("weekly_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  dueDate: timestamp("due_date").notNull(),
  trackType: text("track_type").notNull(),
  icon: text("icon"),
  status: text("status").default("pending"),
});

export const classRegistrations = pgTable("class_registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  userId: integer("user_id").notNull(),
  registeredAt: timestamp("registered_at").defaultNow(),
  attended: boolean("attended").default(false),
  feedback: text("feedback"),
  satisfactionRating: integer("satisfaction_rating"),
  notes: text("notes"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertTrackSchema = createInsertSchema(tracks).omit({
  id: true,
});

export const insertSkillSchema = createInsertSchema(skills).omit({
  id: true,
});

export const insertSkillActivitySchema = createInsertSchema(skillActivities).omit({
  id: true,
  submittedAt: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
});

export const insertWeeklyPlanSchema = createInsertSchema(weeklyPlans).omit({
  id: true,
});

export const insertClassRegistrationSchema = createInsertSchema(classRegistrations).omit({
  id: true,
  registeredAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTrack = z.infer<typeof insertTrackSchema>;
export type Track = typeof tracks.$inferSelect;

export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Skill = typeof skills.$inferSelect;

export type InsertSkillActivity = z.infer<typeof insertSkillActivitySchema>;
export type SkillActivity = typeof skillActivities.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertWeeklyPlan = z.infer<typeof insertWeeklyPlanSchema>;
export type WeeklyPlan = typeof weeklyPlans.$inferSelect;

export type InsertClassRegistration = z.infer<typeof insertClassRegistrationSchema>;
export type ClassRegistration = typeof classRegistrations.$inferSelect;
