import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { json } from "express";
import { 
  insertUserSchema,
  insertTrackSchema, 
  insertSkillSchema, 
  insertSkillActivitySchema,
  insertEventSchema,
  insertWeeklyPlanSchema,
  insertClassRegistrationSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  const apiRouter = app;

  // Get all tracks
  apiRouter.get("/api/tracks", async (req, res) => {
    const tracks = await storage.getTracks();
    res.json(tracks);
  });

  // Get a specific track
  apiRouter.get("/api/tracks/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const track = await storage.getTrack(id);
    
    if (!track) {
      return res.status(404).json({ error: "Track not found" });
    }
    
    res.json(track);
  });

  // Update track progress
  apiRouter.patch("/api/tracks/:id/progress", async (req, res) => {
    const id = parseInt(req.params.id);
    const { progress } = req.body;
    
    if (typeof progress !== "number" || progress < 0 || progress > 100) {
      return res.status(400).json({ error: "Invalid progress value" });
    }
    
    const updatedTrack = await storage.updateTrackProgress(id, progress);
    
    if (!updatedTrack) {
      return res.status(404).json({ error: "Track not found" });
    }
    
    res.json(updatedTrack);
  });

  // Get all skills
  apiRouter.get("/api/skills", async (req, res) => {
    const skills = await storage.getSkills();
    res.json(skills);
  });

  // Get a specific skill
  apiRouter.get("/api/skills/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const skill = await storage.getSkill(id);
    
    if (!skill) {
      return res.status(404).json({ error: "Skill not found" });
    }
    
    res.json(skill);
  });

  // Update skill progress
  apiRouter.patch("/api/skills/:id/progress", async (req, res) => {
    const id = parseInt(req.params.id);
    const { progress } = req.body;
    
    if (typeof progress !== "number" || progress < 0 || progress > 100) {
      return res.status(400).json({ error: "Invalid progress value" });
    }
    
    const updatedSkill = await storage.updateSkillProgress(id, progress);
    
    if (!updatedSkill) {
      return res.status(404).json({ error: "Skill not found" });
    }
    
    res.json(updatedSkill);
  });

  // Get skill activities for a user
  apiRouter.get("/api/users/:userId/skill-activities", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const activities = await storage.getSkillActivities(userId);
    res.json(activities);
  });

  // Get a specific skill activity
  apiRouter.get("/api/skill-activities/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const activity = await storage.getSkillActivity(id);
    
    if (!activity) {
      return res.status(404).json({ error: "Skill activity not found" });
    }
    
    res.json(activity);
  });

  // Submit a response for a skill activity
  apiRouter.post("/api/skill-activities/:id/submit", async (req, res) => {
    const id = parseInt(req.params.id);
    const { response } = req.body;
    
    if (typeof response !== "string" || response.trim() === "") {
      return res.status(400).json({ error: "Response is required" });
    }
    
    const updatedActivity = await storage.updateSkillActivityResponse(id, response);
    
    if (!updatedActivity) {
      return res.status(404).json({ error: "Skill activity not found" });
    }
    
    res.json(updatedActivity);
  });

  // Get all events
  apiRouter.get("/api/events", async (req, res) => {
    const events = await storage.getEvents();
    res.json(events);
  });

  // Get upcoming events
  apiRouter.get("/api/events/upcoming", async (req, res) => {
    const events = await storage.getUpcomingEvents();
    res.json(events);
  });

  // Get a specific event
  apiRouter.get("/api/events/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const event = await storage.getEvent(id);
    
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    
    res.json(event);
  });

  // Create a new event (for instructors/admin)
  apiRouter.post("/api/events", async (req, res) => {
    try {
      const validatedData = insertEventSchema.parse(req.body);
      const newEvent = await storage.createEvent(validatedData);
      res.status(201).json(newEvent);
    } catch (error) {
      res.status(400).json({ error: "Invalid event data" });
    }
  });

  // Update an event (for instructors/admin)
  apiRouter.patch("/api/events/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      const updatedEvent = await storage.updateEvent(id, req.body);
      res.json(updatedEvent);
    } catch (error) {
      res.status(400).json({ error: "Invalid event data" });
    }
  });

  // Delete an event (for instructors/admin)
  apiRouter.delete("/api/events/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const deleted = await storage.deleteEvent(id);
      if (!deleted) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  // Get all registrations for an event
  apiRouter.get("/api/events/:id/registrations", async (req, res) => {
    const eventId = parseInt(req.params.id);
    try {
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      const registrations = await storage.getClassRegistrations(eventId);
      res.json(registrations);
    } catch (error) {
      res.status(500).json({ error: "Failed to get registrations" });
    }
  });

  // Register for a class
  apiRouter.post("/api/class-registrations", async (req, res) => {
    try {
      const validatedData = insertClassRegistrationSchema.parse(req.body);
      const registration = await storage.registerForClass(validatedData);
      res.status(201).json(registration);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid registration data" });
    }
  });

  // Check if a user is registered for an event
  apiRouter.get("/api/events/:eventId/users/:userId/registered", async (req, res) => {
    const eventId = parseInt(req.params.eventId);
    const userId = parseInt(req.params.userId);
    
    try {
      const isRegistered = await storage.checkUserRegistered(eventId, userId);
      res.json({ registered: isRegistered });
    } catch (error) {
      res.status(500).json({ error: "Failed to check registration status" });
    }
  });

  // Get all registrations for a user
  apiRouter.get("/api/users/:userId/class-registrations", async (req, res) => {
    const userId = parseInt(req.params.userId);
    try {
      const registrations = await storage.getUserRegistrations(userId);
      res.json(registrations);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user registrations" });
    }
  });

  // Cancel a registration
  apiRouter.delete("/api/class-registrations/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const canceled = await storage.cancelRegistration(id);
      if (!canceled) {
        return res.status(404).json({ error: "Registration not found" });
      }
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: "Failed to cancel registration" });
    }
  });

  // Update a registration (for marking attendance, providing feedback)
  apiRouter.patch("/api/class-registrations/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const registration = await storage.getClassRegistration(id);
      if (!registration) {
        return res.status(404).json({ error: "Registration not found" });
      }

      const updatedRegistration = await storage.updateRegistration(id, req.body);
      res.json(updatedRegistration);
    } catch (error) {
      res.status(400).json({ error: "Invalid registration data" });
    }
  });

  // Get weekly plans for a user
  apiRouter.get("/api/users/:userId/weekly-plans", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const plans = await storage.getWeeklyPlans(userId);
    res.json(plans);
  });

  // Update weekly plan status
  apiRouter.patch("/api/weekly-plans/:id/status", async (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    
    if (typeof status !== "string" || !["pending", "in-progress", "completed"].includes(status)) {
      return res.status(400).json({ error: "Invalid status value" });
    }
    
    const updatedPlan = await storage.updateWeeklyPlanStatus(id, status);
    
    if (!updatedPlan) {
      return res.status(404).json({ error: "Weekly plan not found" });
    }
    
    res.json(updatedPlan);
  });

  // Get user profile
  apiRouter.get("/api/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const user = await storage.getUser(id);
    
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Don't send password in response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Update user profile
  apiRouter.patch("/api/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const user = await storage.getUser(id);
    
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Remove sensitive fields that shouldn't be updated via this endpoint
    const { id: userId, username, password, ...updatableFields } = req.body;
    
    const updatedUser = await storage.updateUser(id, updatableFields);
    
    if (!updatedUser) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Don't send password in response
    const { password: pwd, ...userWithoutPassword } = updatedUser;
    res.json(userWithoutPassword);
  });

  // For development purposes, set a current user (would normally be done via auth)
  apiRouter.get("/api/current-user", async (req, res) => {
    const users = await Promise.all(
      [1].map(id => storage.getUser(id))
    );
    
    const user = users[0];
    
    if (!user) {
      return res.status(404).json({ error: "Demo user not found" });
    }
    
    // Don't send password in response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  const httpServer = createServer(app);
  return httpServer;
}
