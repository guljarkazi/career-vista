import { 
  users, type User, type InsertUser,
  tracks, type Track, type InsertTrack,
  skills, type Skill, type InsertSkill,
  skillActivities, type SkillActivity, type InsertSkillActivity,
  events, type Event, type InsertEvent,
  weeklyPlans, type WeeklyPlan, type InsertWeeklyPlan,
  classRegistrations, type ClassRegistration, type InsertClassRegistration
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Track methods
  getTracks(): Promise<Track[]>;
  getTrack(id: number): Promise<Track | undefined>;
  createTrack(track: InsertTrack): Promise<Track>;
  updateTrackProgress(id: number, progress: number): Promise<Track | undefined>;
  
  // Skill methods
  getSkills(): Promise<Skill[]>;
  getSkill(id: number): Promise<Skill | undefined>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  updateSkillProgress(id: number, progress: number): Promise<Skill | undefined>;
  
  // Skill Activity methods
  getSkillActivities(userId: number): Promise<SkillActivity[]>;
  getSkillActivity(id: number): Promise<SkillActivity | undefined>;
  createSkillActivity(activity: InsertSkillActivity): Promise<SkillActivity>;
  updateSkillActivityResponse(id: number, response: string): Promise<SkillActivity | undefined>;
  
  // Event methods
  getEvents(): Promise<Event[]>;
  getUpcomingEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<Event>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;
  
  // Class Registration methods
  getClassRegistrations(eventId: number): Promise<ClassRegistration[]>;
  getUserRegistrations(userId: number): Promise<ClassRegistration[]>;
  getClassRegistration(id: number): Promise<ClassRegistration | undefined>;
  checkUserRegistered(eventId: number, userId: number): Promise<boolean>;
  registerForClass(registration: InsertClassRegistration): Promise<ClassRegistration>;
  cancelRegistration(id: number): Promise<boolean>;
  updateRegistration(id: number, data: Partial<ClassRegistration>): Promise<ClassRegistration | undefined>;
  
  // Weekly Plan methods
  getWeeklyPlans(userId: number): Promise<WeeklyPlan[]>;
  getWeeklyPlan(id: number): Promise<WeeklyPlan | undefined>;
  createWeeklyPlan(plan: InsertWeeklyPlan): Promise<WeeklyPlan>;
  updateWeeklyPlanStatus(id: number, status: string): Promise<WeeklyPlan | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getTracks(): Promise<Track[]> {
    return await db.select().from(tracks);
  }

  async getTrack(id: number): Promise<Track | undefined> {
    const [track] = await db.select().from(tracks).where(eq(tracks.id, id));
    return track || undefined;
  }

  async createTrack(insertTrack: InsertTrack): Promise<Track> {
    const [track] = await db
      .insert(tracks)
      .values(insertTrack)
      .returning();
    return track;
  }

  async updateTrackProgress(id: number, progress: number): Promise<Track | undefined> {
    const [track] = await db
      .update(tracks)
      .set({ progress })
      .where(eq(tracks.id, id))
      .returning();
    return track || undefined;
  }

  async getSkills(): Promise<Skill[]> {
    return await db.select().from(skills);
  }

  async getSkill(id: number): Promise<Skill | undefined> {
    const [skill] = await db.select().from(skills).where(eq(skills.id, id));
    return skill || undefined;
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const [skill] = await db
      .insert(skills)
      .values(insertSkill)
      .returning();
    return skill;
  }

  async updateSkillProgress(id: number, progress: number): Promise<Skill | undefined> {
    const [skill] = await db
      .update(skills)
      .set({ progress })
      .where(eq(skills.id, id))
      .returning();
    return skill || undefined;
  }

  async getSkillActivities(userId: number): Promise<SkillActivity[]> {
    return await db
      .select()
      .from(skillActivities)
      .where(eq(skillActivities.userId, userId));
  }

  async getSkillActivity(id: number): Promise<SkillActivity | undefined> {
    const [activity] = await db
      .select()
      .from(skillActivities)
      .where(eq(skillActivities.id, id));
    return activity || undefined;
  }

  async createSkillActivity(insertActivity: InsertSkillActivity): Promise<SkillActivity> {
    const [activity] = await db
      .insert(skillActivities)
      .values(insertActivity)
      .returning();
    return activity;
  }

  async updateSkillActivityResponse(id: number, response: string): Promise<SkillActivity | undefined> {
    const [activity] = await db
      .update(skillActivities)
      .set({ 
        response, 
        submittedAt: new Date()
      })
      .where(eq(skillActivities.id, id))
      .returning();
    return activity || undefined;
  }

  async getEvents(): Promise<Event[]> {
    return await db.select().from(events);
  }

  async getUpcomingEvents(): Promise<Event[]> {
    const now = new Date();
    return await db
      .select()
      .from(events)
      .where(gte(events.date, now))
      .orderBy(({date}) => date);
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || undefined;
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    try {
      // Explicitly specify the fields to avoid type issues
      const result = await db
        .insert(events)
        .values([{
          title: insertEvent.title,
          description: insertEvent.description,
          type: insertEvent.type,
          date: insertEvent.date,
          endDate: insertEvent.endDate,
          location: insertEvent.location,
          instructor: insertEvent.instructor,
          capacity: insertEvent.capacity,
          enrolledCount: insertEvent.enrolledCount || 0,
          status: insertEvent.status,
          meetingLink: insertEvent.meetingLink,
          materials: insertEvent.materials,
          icon: insertEvent.icon,
          iconBackground: insertEvent.iconBackground
        }])
        .returning();
      
      const [event] = result;
      return event;
    } catch (error) {
      console.error("Error creating event:", error);
      throw error;
    }
  }

  async updateEvent(id: number, eventData: Partial<Event>): Promise<Event | undefined> {
    const [event] = await db
      .update(events)
      .set(eventData)
      .where(eq(events.id, id))
      .returning();
    return event || undefined;
  }

  async deleteEvent(id: number): Promise<boolean> {
    const result = await db
      .delete(events)
      .where(eq(events.id, id))
      .returning({ id: events.id });
    return result.length > 0;
  }

  async getClassRegistrations(eventId: number): Promise<ClassRegistration[]> {
    return await db
      .select()
      .from(classRegistrations)
      .where(eq(classRegistrations.eventId, eventId));
  }

  async getUserRegistrations(userId: number): Promise<ClassRegistration[]> {
    return await db
      .select()
      .from(classRegistrations)
      .where(eq(classRegistrations.userId, userId));
  }

  async getClassRegistration(id: number): Promise<ClassRegistration | undefined> {
    const [registration] = await db
      .select()
      .from(classRegistrations)
      .where(eq(classRegistrations.id, id));
    return registration || undefined;
  }

  async checkUserRegistered(eventId: number, userId: number): Promise<boolean> {
    const registrations = await db
      .select()
      .from(classRegistrations)
      .where(and(
        eq(classRegistrations.eventId, eventId),
        eq(classRegistrations.userId, userId)
      ));
    return registrations.length > 0;
  }

  async registerForClass(registration: InsertClassRegistration): Promise<ClassRegistration> {
    // First, check if the user is already registered
    const isRegistered = await this.checkUserRegistered(registration.eventId, registration.userId);
    if (isRegistered) {
      throw new Error("User is already registered for this class");
    }

    // Check if the event exists and has capacity
    const event = await this.getEvent(registration.eventId);
    if (!event) {
      throw new Error("Event not found");
    }

    if (event.capacity !== null && event.enrolledCount !== null && event.enrolledCount >= event.capacity) {
      throw new Error("Class is at full capacity");
    }

    // Create the registration
    const [newRegistration] = await db
      .insert(classRegistrations)
      .values(registration)
      .returning();

    // Update the enrolled count for the event
    if (event.enrolledCount !== null) {
      await this.updateEvent(event.id, { 
        enrolledCount: (event.enrolledCount + 1) 
      });
    }

    return newRegistration;
  }

  async cancelRegistration(id: number): Promise<boolean> {
    // Get the registration first to update the event count
    const registration = await this.getClassRegistration(id);
    if (!registration) {
      return false;
    }

    // Delete the registration
    const result = await db
      .delete(classRegistrations)
      .where(eq(classRegistrations.id, id))
      .returning({ id: classRegistrations.id });

    // Update the enrolled count for the event
    if (result.length > 0) {
      const event = await this.getEvent(registration.eventId);
      if (event && event.enrolledCount !== null && event.enrolledCount > 0) {
        await this.updateEvent(event.id, { 
          enrolledCount: (event.enrolledCount - 1) 
        });
      }
    }

    return result.length > 0;
  }

  async updateRegistration(id: number, data: Partial<ClassRegistration>): Promise<ClassRegistration | undefined> {
    const [registration] = await db
      .update(classRegistrations)
      .set(data)
      .where(eq(classRegistrations.id, id))
      .returning();
    return registration || undefined;
  }

  async getWeeklyPlans(userId: number): Promise<WeeklyPlan[]> {
    return await db
      .select()
      .from(weeklyPlans)
      .where(eq(weeklyPlans.userId, userId));
  }

  async getWeeklyPlan(id: number): Promise<WeeklyPlan | undefined> {
    const [plan] = await db
      .select()
      .from(weeklyPlans)
      .where(eq(weeklyPlans.id, id));
    return plan || undefined;
  }

  async createWeeklyPlan(insertPlan: InsertWeeklyPlan): Promise<WeeklyPlan> {
    const [plan] = await db
      .insert(weeklyPlans)
      .values(insertPlan)
      .returning();
    return plan;
  }

  async updateWeeklyPlanStatus(id: number, status: string): Promise<WeeklyPlan | undefined> {
    const [plan] = await db
      .update(weeklyPlans)
      .set({ status })
      .where(eq(weeklyPlans.id, id))
      .returning();
    return plan || undefined;
  }
}

// Use the DatabaseStorage class for our application
export const storage = new DatabaseStorage();