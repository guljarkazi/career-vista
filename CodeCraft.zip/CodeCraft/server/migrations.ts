import { db } from "./db";
import { sql } from "drizzle-orm";

export async function runMigrations() {
  console.log("Running database migrations...");
  
  try {
    // Add new columns to the events table
    await db.execute(sql`
      ALTER TABLE IF EXISTS events
      ADD COLUMN IF NOT EXISTS end_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS location TEXT,
      ADD COLUMN IF NOT EXISTS instructor TEXT,
      ADD COLUMN IF NOT EXISTS capacity INTEGER,
      ADD COLUMN IF NOT EXISTS enrolled_count INTEGER DEFAULT 0,
      ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'scheduled',
      ADD COLUMN IF NOT EXISTS meeting_link TEXT,
      ADD COLUMN IF NOT EXISTS recording_link TEXT,
      ADD COLUMN IF NOT EXISTS materials JSONB;
    `);
    
    // Create class_registrations table if it doesn't exist
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS class_registrations (
        id SERIAL PRIMARY KEY,
        event_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        attended BOOLEAN DEFAULT FALSE,
        feedback TEXT,
        satisfaction_rating INTEGER,
        notes TEXT
      );
    `);
    
    console.log("Database migrations completed successfully.");
  } catch (error) {
    console.error("Error running migrations:", error);
    throw error;
  }
}