import { db } from "./db";
import { 
  users, tracks, skills, events, weeklyPlans, skillActivities,
  type InsertUser, type InsertTrack, type InsertSkill, 
  type InsertEvent, type InsertWeeklyPlan, type InsertSkillActivity
} from "@shared/schema";

export async function seedDatabase() {
  console.log("Seeding database...");
  
  // Check if database is already seeded
  const existingUsers = await db.select().from(users);
  if (existingUsers.length > 0) {
    console.log("Database already seeded, skipping...");
    return;
  }
  
  try {
    // Insert demo user
    const demoUser: InsertUser = {
      username: "student",
      password: "password123", // In a real app, this would be hashed
      fullName: "Rahul Singh",
      grade: "Grade 10",
      email: "rahul.s@example.com",
      phone: null,
      parentName: "Priya Singh",
      parentEmail: "priya.s@example.com",
      parentPhone: null,
      relationship: "Mother",
      bio: "I'm interested in medicine and engineering. I like to read books and play chess.",
      careerInterests: ["Medicine", "Engineering", "Research"]
    };
    
    const [user] = await db.insert(users).values(demoUser).returning();
    console.log("Created demo user:", user.username);
    
    // Insert tracks
    const medicalTrack: InsertTrack = {
      name: "Medical Track",
      description: "Explore medical science, anatomy, and healthcare careers",
      progress: 35,
      backgroundColor: "#E3F2FD",
      image: "/images/medical.jpg",
      featured: true,
      isNew: false
    };
    
    const engineeringTrack: InsertTrack = {
      name: "Engineering Track",
      description: "Mathematics, physics, and practical engineering applications",
      progress: 20,
      backgroundColor: "#F3E5F5",
      image: "/images/engineering.jpg",
      featured: false,
      isNew: false
    };
    
    const iasTrack: InsertTrack = {
      name: "IAS Preparation",
      description: "Comprehensive civil services exam preparation path",
      progress: 15,
      backgroundColor: "#FFFDE7",
      image: "/images/ias.jpg",
      featured: false,
      isNew: true
    };
    
    const futureTechTrack: InsertTrack = {
      name: "Future Tech",
      description: "AI, robotics, and emerging technologies exploration",
      progress: 10,
      backgroundColor: "#E8F5E9",
      image: "/images/future-tech.jpg",
      featured: true,
      isNew: true
    };
    
    const lifeSkillsTrack: InsertTrack = {
      name: "Life Skills",
      description: "Communication, leadership, and personal development",
      progress: 45,
      backgroundColor: "#FFF3E0",
      image: "/images/life-skills.jpg",
      featured: false,
      isNew: false
    };
    
    await db.insert(tracks).values([
      medicalTrack,
      engineeringTrack,
      iasTrack,
      futureTechTrack,
      lifeSkillsTrack
    ]);
    console.log("Created 5 tracks");
    
    // Insert skills
    const creativeThinking: InsertSkill = {
      name: "Creative Thinking",
      description: "Develop innovative thinking approaches to problem-solving",
      level: "Intermediate",
      progress: 60,
      icon: "ri-lightbulb-line",
      iconColor: "#FFA000"
    };
    
    const teamwork: InsertSkill = {
      name: "Teamwork",
      description: "Collaborate effectively in group settings and team projects",
      level: "Advanced",
      progress: 75,
      icon: "ri-team-line",
      iconColor: "#4CAF50"
    };
    
    const communication: InsertSkill = {
      name: "Communication",
      description: "Express ideas clearly and confidently in both written and spoken forms",
      level: "Beginner",
      progress: 40,
      icon: "ri-chat-3-line",
      iconColor: "#2196F3"
    };
    
    await db.insert(skills).values([
      creativeThinking,
      teamwork,
      communication
    ]);
    console.log("Created 3 skills");
    
    // Insert events
    const liveClass: InsertEvent = {
      title: "Live Class: Human Anatomy",
      description: "Interactive session on the respiratory system with Dr. Sharma",
      type: "class",
      date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      icon: "ri-health-book-line",
      iconBackground: "#E3F2FD"
    };
    
    const bookDiscussion: InsertEvent = {
      title: "Book Discussion: The Wonder of Science",
      description: "Group discussion on chapters 3-5 of our reading assignment",
      type: "discussion",
      date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      icon: "ri-book-open-line",
      iconBackground: "#F3E5F5"
    };
    
    const weeklyQuiz: InsertEvent = {
      title: "Weekly Quiz: Mathematics",
      description: "Practice quiz on trigonometry and calculus basics",
      type: "assessment",
      date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      icon: "ri-edit-2-line",
      iconBackground: "#E8F5E9"
    };
    
    await db.insert(events).values([
      liveClass,
      bookDiscussion,
      weeklyQuiz
    ]);
    console.log("Created 3 events");
    
    // Insert weekly plans
    const humanBodyPlan: InsertWeeklyPlan = {
      title: "Human Body Systems Study",
      description: "Study the respiratory and circulatory systems in detail",
      userId: user.id,
      trackType: "Medical",
      status: "in-progress",
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      icon: "ri-heart-pulse-line"
    };
    
    const wonderBookPlan: InsertWeeklyPlan = {
      title: "Read 'The Wonder of Science' Ch. 3-5",
      description: "Complete reading and make notes on key concepts",
      userId: user.id,
      trackType: "Reading",
      status: "pending",
      dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000), // 4 days from now
      icon: "ri-book-open-line"
    };
    
    const creativeThinkingPlan: InsertWeeklyPlan = {
      title: "Creative Thinking Challenge",
      description: "Complete the weekly creativity exercises and reflection",
      userId: user.id,
      trackType: "Skills",
      status: "completed",
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
      icon: "ri-lightbulb-line"
    };
    
    const trigonometryPlan: InsertWeeklyPlan = {
      title: "Trigonometry Practice Problems",
      description: "Complete the assigned trigonometry worksheet",
      userId: user.id,
      trackType: "Engineering",
      status: "pending",
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      icon: "ri-ruler-2-line"
    };
    
    await db.insert(weeklyPlans).values([
      humanBodyPlan,
      wonderBookPlan,
      creativeThinkingPlan,
      trigonometryPlan
    ]);
    console.log("Created 4 weekly plans");
    
    // Insert a skill activity
    const creativeChallengeActivity: InsertSkillActivity = {
      skillId: 1, // Assuming creative thinking skill has ID 1
      userId: user.id,
      prompt: "Describe a problem you've encountered recently and three non-obvious potential solutions.",
      status: "assigned",
      response: null
    };
    
    await db.insert(skillActivities).values([
      creativeChallengeActivity
    ]);
    console.log("Created 1 skill activity");
    
    console.log("Database seeding completed successfully.");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}